<template>
  <div class="container">
    <div class="row">
      <div v-for="pokemon in pokemon" :key="pokemon.id" class="col-md-4 col-lg-4 col-xl-4 col-sm-6 col-xs-12">
        <div class="card" style="width: 18rem;">
          <img :src="'https://raw.githubusercontent.com/pikachu/'+ pokemon.num + '.png'"/>
          <div class="card-body">
            <h5 class="card-title">{{pokemon.name}}</h5>
            <p class="card-text"> Ipsum dolor sit amet, consectetur adipiscing elit. Donec eu cursus lacus, vitae aliquam mauris. Cras rutrum libero vel urna scelerisque tristique. </p>
            <a href="Cards2.html" class="btn btn-primary">Boton</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    Pokemon: Array,
  },
  
};
</script>


<style scoped>
.pokemon{
    height: 300px;
    display:flex;
    flex-direction: column;
    align-items: center;
    border: 2px solid black
}

.pokemon img{
    max-height: 200px;
    max-width: 250px;
}

.card{
    padding: 2%;
}

</style>