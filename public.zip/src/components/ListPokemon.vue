<template>
  <div>
    <h1>{{ title }}</h1>
    <Pokemon :pokemon="pokemon" />  
  </div>
</template>

<script>
import { onMounted, computed } from "vue";
import { useStore } from "vuex";
import Pokemon from "./Pokemon.vue";

export default {
  components: {
    Pokemon,
  },
  setup() {
    const store = useStore();

    onMounted(() => {
      store.dispatch("getPokemon");
    });

    const title = computed(() => store.state.titleApp);
    const memes = computed(() => store.state.pokemon);

    return {
      title,
      pokemon,
    };
  },
};
</script>

<style>

</style>